/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Destination {
  id: string;
  name: string;
  country: string;
  image: string;
  description: string;
  price: number;
}

export interface Package {
  id: string;
  title: string;
  destination: string;
  duration: string;
  price: number;
  hotel: string;
  inclusions: string[];
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  avatar?: string;
}
