import { motion } from 'motion/react';
import { ShieldCheck, Globe2, HeartHandshake, Award } from 'lucide-react';

export default function About() {
  const stats = [
    { icon: Globe2, label: 'Destinations', value: '150+' },
    { icon: HeartHandshake, label: 'Happy Travelers', value: '50K+' },
    { icon: ShieldCheck, label: 'Safe Tours', value: '10K+' },
    { icon: Award, label: 'Expert Guides', value: '200+' },
  ];

  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-2xl">
              <img 
                src="/src/assets/images/about_travel_team_1794240831333.jpg" 
                alt="Our Professional Travel Team"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 w-64 h-64 bg-cyan-100 rounded-full blur-3xl z-0" />
            <div className="absolute -top-8 -left-8 w-64 h-64 bg-slate-100 rounded-full blur-3xl z-0" />
            
            <div className="absolute -bottom-10 -left-10 bg-white p-8 rounded-3xl shadow-xl z-20 border border-slate-100 hidden md:block">
              <div className="text-4xl font-bold text-cyan-600 mb-1">15+</div>
              <div className="text-slate-500 font-bold uppercase tracking-widest text-xs">Years of Excellence</div>
            </div>
          </motion.div>

          <div>
            <h2 className="text-sm font-bold text-cyan-600 uppercase tracking-widest mb-4">About Global Tour</h2>
            <h3 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              We Craft <span className="text-cyan-600">Authentic</span> Experiences For Every Traveler
            </h3>
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              At Global Tour, we believe that travel is more than just visiting a new place—it's about the stories you bring back and the connections you make. Our mission is to provide seamless, unforgettable adventures that inspire and rejuvenate.
            </p>
            
            <div className="grid grid-cols-2 gap-8 mb-10">
              {stats.map((stat, i) => (
                <div key={i} className="flex flex-col">
                  <div className="flex items-center gap-3 mb-2">
                    <stat.icon className="w-6 h-6 text-cyan-600" />
                    <span className="text-2xl font-bold text-slate-900 tabular-nums">{stat.value}</span>
                  </div>
                  <span className="text-slate-500 text-sm font-medium">{stat.label}</span>
                </div>
              ))}
            </div>

            <a 
              href="#contact"
              className="inline-block px-8 py-4 bg-cyan-600 text-white font-bold rounded-2xl hover:bg-cyan-700 transition-all shadow-lg shadow-cyan-200 text-center"
            >
              CONTACT NOW
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
