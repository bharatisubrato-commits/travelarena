import { motion } from 'motion/react';
import { CheckCircle2, Hotel, Clock, Users, Star, MapPin } from 'lucide-react';
import { Package } from '../types';

const packages: Package[] = [
  {
    id: 'p1',
    title: 'Ultimate Bali Retreat',
    destination: 'Bali, Indonesia',
    duration: '7 Days / 6 Nights',
    price: 1499,
    hotel: 'Maya Ubud Resort & Spa',
    inclusions: ['Round-trip Airfare', 'Luxury Accommodation', 'Daily Breakfast & Dinner', 'Private Guided Tours'],
    image: '/src/assets/images/dest_bali_1794240830552.jpg'
  },
  {
    id: 'p2',
    title: 'European Capital Tour',
    destination: 'Paris & London',
    duration: '10 Days / 9 Nights',
    price: 2899,
    hotel: 'Hôtel Regina Louvre',
    inclusions: ['Business Class Train', '5-Star Hotels', 'Museum Passes', 'Evening Seine Cruise'],
    image: '/src/assets/images/dest_paris_1794240830825.jpg'
  },
  {
    id: 'p3',
    title: 'Japanese Culture & Tech',
    destination: 'Tokyo & Kyoto',
    duration: '8 Days / 7 Nights',
    price: 3200,
    hotel: 'Park Hyatt Tokyo',
    inclusions: ['Bullet Train Pass', 'Tea Ceremony Experience', 'Robotic Cafe Tour', 'English Speaking Guide'],
    image: '/src/assets/images/dest_tokyo_1794240831372.jpg'
  }
];

export default function Packages() {
  return (
    <section id="packages" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-cyan-600 uppercase tracking-widest mb-4">Featured Packages</h2>
          <h3 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">Unforgettable <span className="text-cyan-600">Journeys</span></h3>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto">All-inclusive travel packages designed to give you the most authentic experience of every destination.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-[2.5rem] overflow-hidden shadow-xl border border-slate-100 flex flex-col h-full hover:shadow-2xl transition-shadow duration-300"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={pkg.image} 
                  alt={pkg.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-6 right-6">
                  <div className="px-4 py-2 bg-cyan-600 text-white rounded-2xl font-bold shadow-lg">
                    ${pkg.price}
                  </div>
                </div>
                <div className="absolute top-6 left-6 flex gap-1">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                </div>
              </div>
              
              <div className="p-8 flex flex-col flex-grow">
                <div className="flex items-center gap-3 text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {pkg.duration}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> 2 Person</span>
                </div>
                
                <h4 className="text-2xl font-bold text-slate-900 mb-2">{pkg.title}</h4>
                <p className="text-cyan-600 font-semibold mb-6 flex items-center gap-1.5 text-sm">
                  <MapPin className="w-4 h-4" /> {pkg.destination}
                </p>

                <div className="space-y-4 mb-8">
                  <div className="flex items-start gap-3">
                    <Hotel className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Hotel Details</span>
                      <span className="text-slate-700 font-medium">{pkg.hotel}</span>
                    </div>
                  </div>
                  
                  <div>
                    <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">What's Included</span>
                    <ul className="grid grid-cols-1 gap-2">
                      {pkg.inclusions.map((item, i) => (
                        <li key={i} className="flex items-center gap-2 text-slate-600 text-sm">
                          <CheckCircle2 className="w-4 h-4 text-cyan-500 shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <a 
                  href="#booking"
                  className="w-full py-4 bg-slate-900 hover:bg-cyan-600 text-white rounded-2xl font-bold transition-all group flex items-center justify-center gap-2 text-center"
                >
                  BOOK THIS PACKAGE
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ArrowRight({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
    </svg>
  );
}
