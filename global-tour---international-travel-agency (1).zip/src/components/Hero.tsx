import { motion } from 'motion/react';
import { Search, MapPin, Calendar, Users } from 'lucide-react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, auth } from '../lib/firebase';
import { useState } from 'react';

export default function Hero() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const bookingData = {
      name: 'Hero Search Lead',
      email: 'pending@request.com',
      phone: 'N/A',
      destination: formData.get('destination') as string,
      package: 'Quick Search',
      travelDate: formData.get('travel_date') as string,
      travelers: parseInt(formData.get('travelers') as string, 10) || 1,
      requirements: `Duration: ${formData.get('duration')}`,
      status: 'Pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      userId: auth.currentUser?.uid || null,
    };

    try {
      await addDoc(collection(db, 'bookings'), bookingData);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'bookings');
    }
  };

  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/src/assets/images/hero_travel_paradise_1794240828992.jpg"
          alt="Luxury Tropical Beach Sunset"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full py-12 lg:py-24">
        <div className="max-w-2xl text-white">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-block px-4 py-1.5 bg-cyan-500/20 backdrop-blur-sm border border-cyan-400/30 rounded-full text-cyan-300 text-sm font-semibold mb-6"
          >
            Explore the World with Us
          </motion.span>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-5xl lg:text-7xl font-bold leading-tight mb-6 text-wrap-balance"
          >
            Discover Your Next <span className="text-cyan-400">Great Adventure</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg text-slate-200 mb-10 max-w-xl"
          >
            We curate unique travel experiences tailored to your dreams. From tropical paradises to vibrant cityscapes, find your perfect escape today.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex flex-wrap gap-4"
          >
            <a 
              href="#booking"
              className="px-8 py-4 bg-cyan-600 text-white font-bold rounded-full hover:bg-cyan-700 transition-all shadow-xl shadow-cyan-900/40 text-center"
            >
              BOOK NOW
            </a>
            <a 
              href="#contact"
              className="px-8 py-4 bg-white/10 backdrop-blur-md border border-white/30 text-white font-bold rounded-full hover:bg-white/20 transition-all text-center"
            >
              CONTACT NOW
            </a>
          </motion.div>
        </div>

        {/* Booking Entry Bar */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-16 lg:mt-24"
        >
          {submitted ? (
            <div className="bg-white p-8 rounded-3xl shadow-2xl text-center text-cyan-600 font-bold text-xl flex items-center justify-center gap-3">
              <Search className="w-6 h-6 animate-pulse" /> BOOKING REQUEST SENT!
            </div>
          ) : (
            <form 
              onSubmit={handleSubmit}
              className="bg-white p-4 lg:p-8 rounded-3xl shadow-2xl border border-slate-100 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 items-end"
            >
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5" /> Destination
              </label>
              <input 
                type="text" 
                name="destination"
                placeholder="Where to?" 
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5" /> Travel Date
              </label>
              <input 
                type="date" 
                name="travel_date"
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5" /> Duration
              </label>
              <select name="duration" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all appearance-none">
                <option>3-5 Days</option>
                <option>7-10 Days</option>
                <option>2 Weeks</option>
                <option>1 Month</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Users className="w-3.5 h-3.5" /> Travelers
              </label>
              <select name="travelers" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all appearance-none">
                <option>1 Person</option>
                <option>2 Persons</option>
                <option>3-5 Persons</option>
                <option>Group (6+)</option>
              </select>
            </div>

            <button type="submit" className="h-12 lg:h-[52px] bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-200">
              <Search className="w-5 h-5" />
              SEARCH
            </button>
          </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
