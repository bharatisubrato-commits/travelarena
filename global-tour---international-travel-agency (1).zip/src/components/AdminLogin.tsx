import { useState, useEffect } from 'react';
import { Shield, Sparkles, Loader2 } from 'lucide-react';
import { loginWithGoogle, db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { useFirebase } from '../context/FirebaseContext';
import { useNavigate, useLocation } from 'react-router-dom';

export default function AdminLogin() {
  const { user, isAdmin, loading } = useFirebase();
  const [seeding, setSeeding] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as any)?.from?.pathname || "/admin/dashboard";

  useEffect(() => {
    if (!loading && user && isAdmin) {
      navigate(from, { replace: true });
    }
  }, [user, isAdmin, loading, navigate, from]);

  const seedAdmin = async () => {
    if (!user) return;
    setSeeding(true);
    try {
      await setDoc(doc(db, 'admins', user.uid), {
        email: user.email,
        role: 'admin',
        createdAt: new Date().toISOString()
      });
      alert('Success! You are now an administrator.');
      window.location.reload();
    } catch (error) {
      console.error("Initialization failed:", error);
      alert('Failed to initialize admin. Please check permissions.');
    }
    setSeeding(false);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600"></div>
    </div>
  );

  const isOwner = user?.email === 'bharatisubrato@gmail.com';

  return (
    <div className="min-h-screen py-24 bg-slate-50 flex flex-col items-center justify-center text-center px-6">
      <div className="max-w-md w-full bg-white p-12 rounded-[3rem] shadow-2xl border border-slate-100">
        <Shield className="w-16 h-16 text-cyan-600 mx-auto mb-6" />
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Admin Console</h2>
        <p className="text-slate-500 mb-8">Please sign in with your authorized Google account to manage Global Tour bookings.</p>
        
        {user && !isAdmin ? (
          <div className="mb-8 space-y-6">
            <div className="p-4 bg-red-50 text-red-600 rounded-2xl text-sm font-medium border border-red-100">
              Access Denied: Your account ({user.email}) does not have administrative privileges.
            </div>

            {isOwner && (
              <div className="p-6 bg-cyan-50 border border-cyan-100 rounded-[2rem] text-center">
                <Sparkles className="w-8 h-8 text-cyan-600 mx-auto mb-3" />
                <h3 className="font-bold text-cyan-900 mb-2">Initialize Owner Account</h3>
                <p className="text-xs text-cyan-700 mb-4">You are recognized as the site owner. Click below to grant yourself admin access.</p>
                <button 
                  onClick={seedAdmin}
                  disabled={seeding}
                  className="w-full py-3 bg-cyan-600 text-white font-bold rounded-xl hover:bg-cyan-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-200"
                >
                  {seeding ? <Loader2 className="w-4 h-4 animate-spin" /> : 'INITIALIZE ACCESS'}
                </button>
              </div>
            )}
          </div>
        ) : null}

        <button 
          onClick={loginWithGoogle}
          className="w-full px-8 py-4 bg-white border border-slate-200 text-slate-700 font-bold rounded-2xl hover:bg-slate-50 transition-all shadow-sm flex items-center justify-center gap-3"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5 bg-white rounded-full p-0.5" />
          Sign in with Google
        </button>
        
        <button 
          onClick={() => navigate('/')}
          className="mt-6 text-slate-400 text-sm font-medium hover:text-cyan-600 transition-colors"
        >
          Back to Website
        </button>
      </div>
    </div>
  );
}
