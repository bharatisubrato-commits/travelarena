import { motion } from 'motion/react';
import { Ticket, Percent, Sparkles, Send } from 'lucide-react';

export default function Offers() {
  return (
    <section id="offers" className="py-24 bg-slate-900 text-white overflow-hidden relative">
      {/* Decorative patterns */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px]" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/10 rounded-full blur-[100px]" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <h2 className="text-cyan-400 font-bold uppercase tracking-widest text-sm mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Exclusive Offers
            </h2>
            <h3 className="text-4xl lg:text-6xl font-bold mb-8 leading-tight">
              Get Up To <span className="text-cyan-400">30% OFF</span> On Your First Group Trip
            </h3>
            <p className="text-slate-400 text-lg mb-10 leading-relaxed">
              Subscribe to our newsletter and unlock hidden deals, early bird discounts, and seasonal offers delivered straight to your inbox.
            </p>
            
            <form 
              action="https://formspree.io/f/YOUR_FORMSPREE_ID"
              method="POST"
              className="flex flex-col sm:flex-row gap-4"
            >
              <input 
                type="email" 
                name="email"
                required
                placeholder="Enter your email"
                className="flex-grow px-6 py-4 bg-white/10 border border-white/20 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all placeholder:text-slate-500"
              />
              <button type="submit" className="px-8 py-4 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2">
                SUBSCRIBE <Send className="w-4 h-4" />
              </button>
            </form>
          </div>

          <div className="lg:w-1/2 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <motion.div 
              whileHover={{ y: -10 }}
              className="p-8 bg-white/5 border border-white/10 rounded-3xl backdrop-blur-sm"
            >
              <Ticket className="w-10 h-10 text-cyan-400 mb-6" />
              <h4 className="text-xl font-bold mb-3">Early Bird</h4>
              <p className="text-slate-400 text-sm">Book 6 months in advance and save 15% on all packages.</p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -10 }}
              className="p-8 bg-white/5 border border-white/10 rounded-3xl backdrop-blur-sm"
            >
              <Percent className="w-10 h-10 text-cyan-400 mb-6" />
              <h4 className="text-xl font-bold mb-3">Last Minute</h4>
              <p className="text-slate-400 text-sm">Spontaneous? Check our weekly last-minute flash sales.</p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
