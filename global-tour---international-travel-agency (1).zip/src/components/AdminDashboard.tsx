import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc, Timestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, logout } from '../lib/firebase';
import { useFirebase } from '../context/FirebaseContext';
import { Shield, LogOut, CheckCircle, XCircle, Clock, Trash2, ChevronRight, User, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  destination: string;
  package: string;
  travelDate: string;
  travelers: number;
  requirements: string;
  status: 'Pending' | 'Confirmed' | 'Cancelled';
  createdAt: Timestamp;
}

export default function AdminDashboard() {
  const { user, isAdmin, loading } = useFirebase();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filter, setFilter] = useState<'All' | 'Pending' | 'Confirmed' | 'Cancelled'>('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!isAdmin) return;

    const q = query(collection(db, 'bookings'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Booking[];
      setBookings(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'bookings');
    });

    return () => unsubscribe();
  }, [isAdmin]);

  const updateStatus = async (id: string, status: string) => {
    try {
      await updateDoc(doc(db, 'bookings', id), { 
        status,
        updatedAt: new Timestamp(Date.now() / 1000, 0)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `bookings/${id}`);
    }
  };

  const deleteBooking = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this booking?')) return;
    try {
      await deleteDoc(doc(db, 'bookings', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `bookings/${id}`);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600"></div>
    </div>
  );

  const filteredBookings = bookings.filter(b => {
    const matchesStatus = filter === 'All' || b.status === filter;
    const matchesSearch = 
      b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.travelDate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.package.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.email.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <section className="py-12 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-8">
          <button 
            onClick={() => navigate('/')}
            className="text-cyan-600 font-bold text-sm flex items-center gap-2 hover:gap-3 transition-all"
          >
            ← BACK TO WEBSITE
          </button>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 text-cyan-600 font-bold uppercase tracking-widest text-xs mb-2">
              <Shield className="w-4 h-4" /> Admin Console
            </div>
            <h2 className="text-4xl font-bold text-slate-900">Booking Management</h2>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-grow md:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search name, destination, date..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all text-sm"
              />
            </div>
            <div className="bg-white p-2 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-3 px-4 shrink-0">
              <div className="w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-600">
                <User className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium text-slate-700 hidden sm:inline">{user?.email}</span>
              <button 
                onClick={logout}
                className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Stats & Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {[
            { label: 'All', count: bookings.length, color: 'bg-slate-900', active: filter === 'All' },
            { label: 'Pending', count: bookings.filter(b => b.status === 'Pending').length, color: 'bg-yellow-500', active: filter === 'Pending' },
            { label: 'Confirmed', count: bookings.filter(b => b.status === 'Confirmed').length, color: 'bg-green-500', active: filter === 'Confirmed' },
            { label: 'Cancelled', count: bookings.filter(b => b.status === 'Cancelled').length, color: 'bg-red-500', active: filter === 'Cancelled' },
          ].map((s) => (
            <button
              key={s.label}
              onClick={() => setFilter(s.label as any)}
              className={`p-6 rounded-3xl text-left transition-all ${s.active ? `${s.color} text-white shadow-xl` : 'bg-white text-slate-900 border border-slate-200 hover:border-cyan-200'}`}
            >
              <span className={`block text-xs font-bold uppercase tracking-widest mb-2 ${s.active ? 'text-white/70' : 'text-slate-400'}`}>{s.label}</span>
              <span className="text-3xl font-bold tabular-nums">{s.count}</span>
            </button>
          ))}
        </div>

        {/* Bookings List */}
        <div className="space-y-4">
          {filteredBookings.length === 0 ? (
            <div className="bg-white p-20 rounded-[3rem] text-center border border-slate-200">
              <Clock className="w-12 h-12 text-slate-200 mx-auto mb-4" />
              <p className="text-slate-400">No bookings found for this filter.</p>
            </div>
          ) : (
            filteredBookings.map((booking) => (
              <motion.div
                layout
                key={booking.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all group"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                  <div className="lg:col-span-3">
                    <h4 className="font-bold text-slate-900 mb-1">{booking.name}</h4>
                    <p className="text-slate-500 text-sm mb-1">{booking.email}</p>
                    <p className="text-slate-400 text-xs font-mono">{booking.phone}</p>
                  </div>

                  <div className="lg:col-span-3">
                    <div className="flex items-center gap-2 text-cyan-600 text-xs font-bold uppercase mb-1">
                      {booking.destination} <ChevronRight className="w-3 h-3" /> {booking.package}
                    </div>
                    <div className="flex items-center gap-4 text-slate-500 text-sm">
                      <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> {booking.travelDate}</span>
                      <span className="flex items-center gap-1.5"><User className="w-3.5 h-3.5" /> {booking.travelers}</span>
                    </div>
                  </div>

                  <div className="lg:col-span-3">
                    <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                      booking.status === 'Confirmed' ? 'bg-green-100 text-green-700' :
                      booking.status === 'Cancelled' ? 'bg-red-100 text-red-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {booking.status === 'Confirmed' && <CheckCircle className="w-3.5 h-3.5" />}
                      {booking.status === 'Cancelled' && <XCircle className="w-3.5 h-3.5" />}
                      {booking.status === 'Pending' && <Clock className="w-3.5 h-3.5" />}
                      {booking.status}
                    </div>
                  </div>

                  <div className="lg:col-span-3 flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => updateStatus(booking.id, 'Confirmed')}
                      className="p-2 rounded-xl bg-green-50 text-green-600 hover:bg-green-600 hover:text-white transition-all"
                      title="Confirm"
                    >
                      <CheckCircle className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={() => updateStatus(booking.id, 'Cancelled')}
                      className="p-2 rounded-xl bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition-all"
                      title="Cancel"
                    >
                      <XCircle className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={() => deleteBooking(booking.id)}
                      className="p-2 rounded-xl bg-slate-50 text-slate-400 hover:bg-slate-900 hover:text-white transition-all"
                      title="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {booking.requirements && (
                  <div className="mt-4 pt-4 border-t border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Requirements:</span>
                    <p className="text-slate-600 text-xs italic">{booking.requirements}</p>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
