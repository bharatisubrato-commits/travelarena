import { motion } from 'motion/react';
import { MapPin, ArrowRight } from 'lucide-react';
import { Destination } from '../types';

const destinations: Destination[] = [
  {
    id: '1',
    name: 'Bali',
    country: 'Indonesia',
    image: '/src/assets/images/dest_bali_1794240830552.jpg',
    description: 'Experience the magic of Balinese culture and stunning landscapes.',
    price: 1200
  },
  {
    id: '2',
    name: 'Paris',
    country: 'France',
    image: '/src/assets/images/dest_paris_1794240830825.jpg',
    description: 'The city of lights, love, and world-class art and cuisine.',
    price: 1800
  },
  {
    id: '3',
    name: 'Tokyo',
    country: 'Japan',
    image: '/src/assets/images/dest_tokyo_1794240831372.jpg',
    description: 'A futuristic metropolis where tradition meets cutting-edge tech.',
    price: 2200
  },
  {
    id: '4',
    name: 'Swiss Alps',
    country: 'Switzerland',
    image: '/src/assets/images/dest_swiss_alps_1794240831048.jpg',
    description: 'Breathtaking mountain vistas and pristine alpine nature.',
    price: 2500
  }
];

export default function Destinations() {
  return (
    <section id="destinations" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-sm font-bold text-cyan-600 uppercase tracking-widest mb-4">Top Destinations</h2>
            <h3 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">Popular Places To <span className="text-cyan-600">Discover</span></h3>
            <p className="text-lg text-slate-500">We've handpicked these amazing destinations just for you. Explore the best the world has to offer.</p>
          </div>
          <button className="flex items-center gap-2 text-cyan-600 font-bold hover:gap-3 transition-all whitespace-nowrap">
            VIEW ALL DESTINATIONS <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {destinations.map((dest, index) => (
            <motion.div
              key={dest.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[4/3] rounded-3xl overflow-hidden mb-6 shadow-lg">
                <img 
                  src={dest.image} 
                  alt={dest.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4">
                  <div className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-bold text-slate-900 flex items-center gap-1.5 shadow-sm">
                    <MapPin className="w-3 h-3 text-cyan-600" />
                    {dest.country}
                  </div>
                </div>
              </div>
              <div className="flex justify-between items-start mb-2">
                <h4 className="text-xl font-bold text-slate-900 group-hover:text-cyan-600 transition-colors">{dest.name}</h4>
                <div className="text-right">
                  <span className="text-sm text-slate-500 block">From</span>
                  <span className="text-lg font-bold text-cyan-600">${dest.price}</span>
                </div>
              </div>
              <p className="text-slate-500 text-sm leading-relaxed line-clamp-2">{dest.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
