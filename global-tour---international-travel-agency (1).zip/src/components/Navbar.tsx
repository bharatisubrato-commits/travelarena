import { motion } from 'motion/react';
import { Plane, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'Destinations', href: '#destinations' },
    { name: 'Packages', href: '#packages' },
    { name: 'About Us', href: '#about' },
    { name: 'Offers', href: '#offers' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
        {/* Zone 1: Brand */}
        <a href="/" className="flex items-center gap-2 text-2xl font-bold tracking-tight text-cyan-600 whitespace-nowrap shrink-0">
          <Plane className="w-8 h-8 rotate-45" />
          <span>GLOBAL TOUR</span>
        </a>

        {/* Zone 2: Nav Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="hover:text-cyan-600 transition-colors whitespace-nowrap shrink-0"
            >
              {link.name}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary CTA (Desktop) */}
        <div className="hidden md:flex items-center gap-3 shrink-0">
          <a 
            href="#booking"
            className="px-6 py-2.5 text-sm font-semibold text-white bg-cyan-600 rounded-full hover:bg-cyan-700 transition-all shadow-lg shadow-cyan-200 whitespace-nowrap shrink-0 text-center"
          >
            BOOK NOW
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden p-2 text-slate-600"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-white border-b border-slate-200 p-6 flex flex-col gap-4"
        >
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-lg font-medium text-slate-600 hover:text-cyan-600"
              onClick={() => setIsOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <a 
            href="#booking"
            onClick={() => setIsOpen(false)}
            className="w-full mt-2 px-6 py-3 text-base font-semibold text-white bg-cyan-600 rounded-xl hover:bg-cyan-700 transition-all text-center"
          >
            BOOK NOW
          </a>
        </motion.div>
      )}
    </header>

  );
}
