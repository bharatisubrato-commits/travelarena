import { Navigate, useLocation } from 'react-router-dom';
import { useFirebase } from '../context/FirebaseContext';

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isAdmin, loading } = useFirebase();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600"></div>
      </div>
    );
  }

  if (!user || !isAdmin) {
    // Redirect to login but save the current location they were trying to go to
    return <Navigate to="/admin" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}
