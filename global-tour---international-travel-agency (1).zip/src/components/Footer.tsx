import { Plane, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Footer() {
  const navigate = useNavigate();
  return (
    <footer className="bg-white border-t border-slate-200 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-1">
            <a href="/" className="flex items-center gap-2 text-2xl font-bold tracking-tight text-cyan-600 mb-6">
              <Plane className="w-8 h-8 rotate-45" />
              <span>GLOBAL TOUR</span>
            </a>
            <p className="text-slate-500 mb-8 max-w-xs">
              Making international travel accessible, authentic, and unforgettable for everyone.
            </p>
            <div className="flex gap-4">
              {[Facebook, Instagram, Twitter, Linkedin].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:text-cyan-600 hover:border-cyan-600 transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Quick Links</h4>
            <ul className="space-y-4">
              {['Home', 'Destinations', 'Packages', 'About Us', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '')}`} className="text-slate-500 hover:text-cyan-600 transition-colors">{link}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Support</h4>
            <ul className="space-y-4">
              {['FAQ', 'Privacy Policy', 'Terms of Service', 'Booking Guide', 'Travel Insurance'].map((link) => (
                <li key={link}>
                  <a href="#" className="text-slate-500 hover:text-cyan-600 transition-colors">{link}</a>
                </li>
              ))}
              <li>
                <button 
                  onClick={() => navigate('/admin')}
                  className="text-slate-500 hover:text-cyan-600 transition-colors cursor-pointer"
                >
                  Admin Console
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 mb-6">Newsletter</h4>
            <p className="text-slate-500 mb-6 text-sm">Join 20,000+ travelers for exclusive deals and travel tips.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email"
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-all text-sm"
              />
              <button className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-bold hover:bg-cyan-600 transition-all">
                JOIN
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-sm">
          <p>© 2026 Global Tour Agency. All rights reserved.</p>
          <div className="flex gap-8 items-center">
            <a href="#" className="hover:text-cyan-600 transition-colors">Privacy</a>
            <a href="#" className="hover:text-cyan-600 transition-colors">Terms</a>
            <button 
              onClick={() => navigate('/admin')}
              className="text-xs font-bold uppercase tracking-widest text-slate-500 hover:text-cyan-600 transition-colors flex items-center gap-1.5"
            >
              <span className="w-1 h-1 rounded-full bg-slate-500" /> Admin Console
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
