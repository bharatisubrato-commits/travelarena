import { motion } from 'motion/react';
import { Quote, Star } from 'lucide-react';
import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Solo Traveler',
    content: "Global Tour made my first solo trip to Bali absolutely seamless. The attention to detail and the quality of hotels exceeded all my expectations!",
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Photography Enthusiast',
    content: "The custom itinerary they built for my Japan photography tour was perfect. They knew all the best spots that aren't in the usual guidebooks.",
  },
  {
    id: '3',
    name: 'Emily & David',
    role: 'Honeymooners',
    content: "We couldn't have asked for a more romantic honeymoon in Paris. Everything from the flights to the evening cruises was perfectly coordinated.",
  }
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-cyan-600 uppercase tracking-widest mb-4">Testimonials</h2>
          <h3 className="text-4xl font-bold text-slate-900">What Our <span className="text-cyan-600">Travelers</span> Say</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex flex-col"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
              </div>
              
              <div className="flex-grow">
                <Quote className="w-8 h-8 text-cyan-200 mb-4" />
                <p className="text-slate-600 leading-relaxed italic mb-8">"{t.content}"</p>
              </div>

              <div className="flex items-center gap-4 border-t border-slate-200 pt-6">
                <div className="w-12 h-12 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-600 font-bold text-lg">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{t.name}</h4>
                  <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
