import { motion } from 'motion/react';
import { Send, MapPin, Calendar, Users, Phone, User, Mail, MessageSquare, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, auth } from '../lib/firebase';

export default function BookingForm() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const bookingData = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      phone: formData.get('phone') as string,
      destination: formData.get('destination') as string,
      package: formData.get('package') as string,
      travelDate: formData.get('travel_date') as string,
      travelers: parseInt(formData.get('travelers') as string, 10),
      requirements: formData.get('requirements') as string || '',
      status: 'Pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      userId: auth.currentUser?.uid || null,
    };

    try {
      await addDoc(collection(db, 'bookings'), bookingData);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'bookings');
    }
  };

  return (
    <section id="booking" className="py-24 bg-cyan-600">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-sm font-bold text-white uppercase tracking-widest mb-4">Reservation</h2>
          <h3 className="text-4xl lg:text-5xl font-bold text-white mb-6">Book Your <span className="text-cyan-200">Tour Package</span></h3>
          <p className="text-lg text-cyan-50/80 max-w-2xl mx-auto">Fill out the details below to reserve your spot. Our team will contact you to finalize the payment and itinerary.</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white p-8 lg:p-12 rounded-[3rem] shadow-2xl"
        >
          {submitted ? (
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-green-600 mx-auto mb-6">
                <Send className="w-10 h-10" />
              </div>
              <h4 className="text-3xl font-bold text-slate-900 mb-4">Booking Received!</h4>
              <p className="text-slate-500 max-w-md mx-auto mb-8">
                Your tour reservation has been sent. We'll be in touch within 24 hours to confirm your details.
              </p>
              <button 
                onClick={() => setSubmitted(false)}
                className="px-8 py-3 bg-cyan-600 text-white font-bold rounded-xl hover:bg-cyan-700 transition-all"
              >
                Make Another Booking
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Personal Info */}
                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Personal Information</h4>
                  
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                      <User className="w-3.5 h-3.5 text-cyan-600" /> Full Name
                    </label>
                    <input required name="name" type="text" placeholder="John Doe" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all" />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-cyan-600" /> Email Address
                    </label>
                    <input required name="email" type="email" placeholder="john@example.com" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all" />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-cyan-600" /> Phone Number
                    </label>
                    <input required name="phone" type="tel" placeholder="+1 (555) 000-0000" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all" />
                  </div>
                </div>

                {/* Tour Details */}
                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Tour Details</h4>
                  
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-cyan-600" /> Destination
                    </label>
                    <select name="destination" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all appearance-none">
                      <option>Bali, Indonesia</option>
                      <option>Paris, France</option>
                      <option>Tokyo, Japan</option>
                      <option>Swiss Alps, Switzerland</option>
                      <option>Other</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-600" /> Selected Package
                    </label>
                    <select name="package" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all appearance-none">
                      <option>Ultimate Bali Retreat</option>
                      <option>European Capital Tour</option>
                      <option>Japanese Culture & Tech</option>
                      <option>Custom Package</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-cyan-600" /> Date
                      </label>
                      <input required name="travel_date" type="date" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                        <Users className="w-3.5 h-3.5 text-cyan-600" /> Travelers
                      </label>
                      <input required name="travelers" type="number" min="1" defaultValue="1" className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-700 uppercase flex items-center gap-2">
                      <MessageSquare className="w-3.5 h-3.5 text-cyan-600" /> Special Requirements
                    </label>
                    <textarea name="requirements" rows={3} placeholder="Dietary needs, accessibility, etc." className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all resize-none"></textarea>
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full py-6 bg-slate-900 hover:bg-cyan-600 text-white font-bold rounded-2xl transition-all shadow-xl flex items-center justify-center gap-3 text-lg">
                SUBMIT BOOKING <Send className="w-6 h-6" />
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
