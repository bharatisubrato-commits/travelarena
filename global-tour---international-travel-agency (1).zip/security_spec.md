# Security Specification - Global Tour

## Data Invariants
1. A booking must have a valid status from the allowed enum (Pending, Confirmed, Cancelled).
2. `createdAt` and `updatedAt` must be server-validated timestamps.
3. Only admins can read all bookings or update booking status.
4. Anonymous users can create bookings but cannot read or modify them after submission.
5. Admins are defined in the `/admins` collection.

## The Dirty Dozen Payloads
1. Create booking with invalid email format.
2. Create booking without required 'name' field.
3. Update booking status as a non-admin user.
4. Read bookings collection as an unauthenticated user.
5. Create booking with a fake 'createdAt' timestamp from the past.
6. Inject 1MB string into 'requirements' field.
7. Inject HTML/Script into 'destination' field.
8. Set 'status' to 'Confirmed' during initial creation by a standard user.
9. Delete a booking as a standard user.
10. Update 'userId' field after creation to someone else's UID.
11. Add 'isAdmin: true' to a standard user booking payload.
12. Bulk read bookings via collection group query without being an admin.

## Test Runner Logic
Verification will ensure:
- `create` allows anyone but strictly validates schema and initial status.
- `list/get` is restricted to admins.
- `update` is restricted to admins (specifically for status changes).
- `delete` is restricted to admins.
